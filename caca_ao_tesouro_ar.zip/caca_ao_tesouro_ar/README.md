# Caça ao Tesouro AR

Protótipo demonstrativo em HTML, CSS e JavaScript, usando A-Frame + AR.js.

## Testar rapidamente
1. Abra `index.html` no computador para conferir o visual e clique em **Testar demonstração**.
2. Para testar a câmera no celular, publique a pasta em um serviço de hospedagem estática com HTTPS (por exemplo, GitHub Pages, Netlify ou Vercel).
3. Abra o endereço HTTPS no celular e toque em **Iniciar modo AR**.
4. Aponte a câmera para um marcador Hiro. Você pode abrir/baixar o marcador oficial aqui:
   https://ar-js-org.github.io/AR.js/data/images/hiro.png
5. Toque no baú na tela para ganhar moedas.

## QR Code
Depois de publicar e obter a URL pública:
- gere um QR Code que contenha a URL do site;
- imprima-o ou mostre-o em outra tela;
- escaneie com o celular para abrir o jogo.

Importante: neste protótipo, o QR Code abre a página. O AR.js usa um marcador visual (Hiro) para posicionar o baú no ambiente. Isso evita depender de recursos WebXR que variam entre navegadores/dispositivos.

## Limitações
- O modo AR precisa de internet para carregar A-Frame/AR.js e de permissão de câmera.
- A demonstração com emojis funciona em navegadores comuns, sem câmera.
- O modo AR usa rastreamento por marcador, não posicionamento livre no ambiente. Para AR sem marcador, seria necessário WebXR hit-test/anchors e um navegador compatível.
